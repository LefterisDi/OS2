#ifndef __LIST_H__
#define __LIST_H__

#include "../MM/mm.h"

typedef struct node {
   HashData data;
   struct node *next;
}ListNode; 


void insert_at_begin(HashData , ListNode**);
int delete_from_begin(ListNode**);
int search_in_list(char* , ListNode*);
int delete_from_list(ListNode**, char*);
#endif