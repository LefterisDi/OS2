#include <stdio.h>
#include <stdlib.h>
#include <string.h>
 
#include "../MM/mm.h"
#include "./list.h"



void insert_at_begin(HashData x , ListNode** startp) {
   
   ListNode* t;
   
   t = (ListNode*)malloc(sizeof(ListNode));

   if (*startp == NULL) {
      *startp = t;
      (*startp)->data = x;
      (*startp)->next = NULL;
      return;
    }
   
   t->data = x;
   t->next = *startp;
   *startp = t;
}

int delete_from_begin(ListNode** startp) {
   struct node *t;
   
   if (*startp == NULL) {
      return 1;
   }

   t = (*startp)->next;
   free(*startp);
   *startp = t;
   
   return 0;
}

int search_in_list(char* pageNum , ListNode* start){

   while(start != NULL){
      if (strcmp(pageNum , start->data.pageNum) == 0){
         return 0;
      }
      start = start->next;
   }

   return 1;
}
int delete_from_list(ListNode** startp , char* pageNum) {
   
   ListNode* t;
   ListNode* tempStart;
   tempStart = *startp;
   
   if (tempStart == NULL) {
      return 1;
   }

   while(tempStart != NULL){
      if (strcmp(pageNum , tempStart->data.pageNum) == 0 && tempStart == *startp){
         delete_from_begin(startp);
         return 0;
      }
      else if (strcmp(pageNum , tempStart->data.pageNum) == 0){
         t->next = tempStart->next;
         free(tempStart);
         return 0;
      }
      t = tempStart;
      tempStart = tempStart->next;
   }

   return 0;
}