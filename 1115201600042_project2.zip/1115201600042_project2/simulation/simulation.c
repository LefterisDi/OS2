#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../sharedMemory/shmCtrl.h"
#include "../semaphores/semCtrl.h"
#include "../sharedMemory/shmStruct.h"


int main(int argc , char* argv[]){

    pid_t wpid;
    int status = 0;
    
    int maxPageFaults;
    int numberOfCells;
    int maxReadsPerFile;
    int maxNumberOfRefs = -1;
    
    int flag = 0;
    short kOnce = 0;
    short qOnce = 0;
    short cOnce = 0;

    key_t shmkey;
    key_t arrayKey;
    int shm_file;
    int shm_id;

    key_t semkey;
    int sem_file;
    int sem_id;

    Data* data;
   
    while(--argc > 0){
    
    if (strcmp(*argv , "-K") == 0 && kOnce == 0){
      argv++;
      argc--;
      maxPageFaults = atoi(*argv);
      flag++;
      kOnce++;
    }

    if (strcmp(*argv , "-Q") == 0 && qOnce == 0){
      argv++;
      argc--;
      maxReadsPerFile = atoi(*argv);
      flag++;
      qOnce++;
    }

    if (strcmp(*argv , "-C") == 0 && cOnce == 0){
      argv++;
      argc--;
      numberOfCells = atoi(*argv);
      flag++;
      cOnce++;
    }

     if (strcmp(*argv , "-M") == 0){
      argv++;
      argc--;
      maxNumberOfRefs = atoi(*argv);
    }

    if (argc > 0){
      argv++;
    }
  }

  if (flag != 3){
    printf("Not all expected data were given!\n");
    exit(1);
  }

  if ((shmkey = create_store_shmemkey("./MM/mm.c" , 'M' , "shmem.key")) < 0){//creates a key in order to store the starting time
    exit(1);
  }

  if ((arrayKey = create_store_shmemkey("./MM/mm.c" , 'A' , "shmemArray.key")) < 0){//creates a key in order to store the starting time
    exit(1);
  }

  if ((data = createData(shmkey , arrayKey , maxReadsPerFile)) == NULL){
    perror("Couldn't allocate shared memory");
    exit(1);
  }
  

  /*creates and stores the semaphore key to a file , so that the children can get access to it*/

  if ((semkey = create_store_semkey("./MM/mm.c" , 'S' , "sem.key")) < 0){
    exit(1);
  }

  if ((sem_id = semget(semkey , 4 , IPC_EXCL | IPC_CREAT | 0666)) < 0){
    perror("semget error!\n");
    exit(-2);
  }

  if (set_semval_one(sem_id , 0) < 0){
    perror("Error while initializing the semaphore");
    exit(-3);
  }

  for (unsigned short i = 1 ; i < 4 ; i++){//initializing the semaphores
    if (set_semval_zero(sem_id , i) < 0){
      perror("Error while initializing the semaphore");
      exit(-3);
    }
  }
  
  
  
  if (fork() == 0){//creating PM1 and giving it its data
    char maxReadsPF[32];
    char maxNumR[32];
    char typeofPm[32];
    sprintf(maxReadsPF , "%d", maxReadsPerFile);
    sprintf(maxNumR , "%d", maxNumberOfRefs);
    sprintf(typeofPm , "%d" , 1);
    if (execl("./PM/pm" , "-Q" , maxReadsPF , "-M" , maxNumR , "-T" , typeofPm , "-F" , "./PM/bzip.trace" , (char *)0) < 0){
      perror("execl error!\n");
      exit(1);
    }
    exit(0);
  }

   if (fork() == 0){//creating PM2 and giving it its data
    char maxReadsPF[32];
    char maxNumR[32];
    char typeofPm[32];
    sprintf(maxReadsPF , "%d", maxReadsPerFile);
    sprintf(maxNumR , "%d", maxNumberOfRefs);
    sprintf(typeofPm , "%d" , 2);
    if (execl("./PM/pm" , "-Q" , maxReadsPF , "-M" , maxNumR , "-T" , typeofPm ,  "-F" , "./PM/gcc.trace"  , (char *)0) < 0){
      perror("execl error!\n");
      exit(1);
    }
    exit(0);
  }

  if (fork() == 0){//passing parameters and executing MM
    char maxReadsPF[32];
    char maxNumR[32];
    char maxPF[32];
    char cellNum[32];
    sprintf(maxReadsPF , "%d", maxReadsPerFile);
    sprintf(maxNumR , "%d", maxNumberOfRefs);
    sprintf(maxPF , "%d" , maxPageFaults);
    sprintf(cellNum , "%d" , numberOfCells);
    if (execl("./MM/mm" , "-Q" , maxReadsPF , "-M" , maxNumR , "-K" , maxPF , "-C" , cellNum , (char *)0) < 0){
      perror("execl error!\n");
      exit(1);
    }
    exit(0);
  }

  while ((wpid = wait(&status)) > 0);//waits for all children to finish


  if(sem_delete(sem_id , 0) < 0){ //deletes things created and used by the program
    perror("semaphore memory delete error!");
    exit(-1);
  }

  if(deleteData(shmkey , arrayKey) < 0){
    perror("shared memory delete error!");
  }

  if (remove("./shmem.key") != 0){
    perror("Couldn't delete file\n");
    exit(1);
  }

  if (remove("./sem.key") != 0){
    perror("Couldn't delete file\n");
    exit(1);
  }

  if (remove("./shmemArray.key") != 0){
    perror("Couldn't delete file\n");
    exit(1);
  }

  return 0;
}