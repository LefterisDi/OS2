#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ipc.h>

#include "../sharedMemory/shmStruct.h"
#include "../sharedMemory/shmCtrl.h"
#include "../semaphores/semCtrl.h"

int main(int argc , char* argv[]){

    int maxPageFaults;
    int numberOfCells;
    int maxReadsPerFile;
    int maxNumberOfReads = 1;  
    int typeOfPm;
    char file[32];

    int definedMaxNumR = 0;

    key_t shm;
    key_t array;
    int shm_id;
    Data* sharedMem;

    key_t sem;
    int sem_id;

    FILE* gen_fp;

        
        
    while(--argc > 0){
    
    if (strcmp(*argv , "-K") == 0){
      argv++;
      argc--;
      maxPageFaults = atoi(*argv);
    }

    if (strcmp(*argv , "-Q") == 0){
      argv++;
      argc--;
      maxReadsPerFile = atoi(*argv);
    }

     if (strcmp(*argv , "-M") == 0){
      argv++;
      argc--;
      maxNumberOfReads = atoi(*argv);
      if (maxNumberOfReads != -1){
        definedMaxNumR = 1;
      }
    }

    if (strcmp(*argv , "-T") == 0){
      argv++;
      argc--;
      typeOfPm = atoi(*argv);
    }

    if (strcmp(*argv , "-F") == 0){
      argv++;
      argc--;
      strcpy(file , *argv);
    }

    if (argc > 0){
      argv++;
    }
  }
  

  shm = get_shmemkey("./shmem.key");
  array = get_shmemkey("./shmemArray.key");


  sem = get_semkey("./sem.key");
  sem_id = semget(sem , 0 , 0);

  if (sem_id < 0){
    perror("checkSem recovery error");
    exit(1);
  }

  gen_fp = fopen(file , "r");
  if (gen_fp == NULL) {
    perror("Cannot open file");
    exit(EXIT_FAILURE);
  }

  int fileFinished = 0;
  int numOfReads = 0;
  
  while(fileFinished == 0){//while the trace file has more data


    if (definedMaxNumR == 1){//checks if we have reached the maximum amount of data we are allowed to read

      if(numOfReads >= maxNumberOfReads){
        break;
      }
    }


    if(sem_down(sem_id , typeOfPm) < 0){ //takes its own semaphore down
      exit(1);
    }

    if(sem_down(sem_id , 0) < 0){//takes shared memory semaphore down 
      exit(1);
    }


    sharedMem = connectData(shm , array , typeOfPm);//connects to shared memory

    char* line = NULL;
    size_t len = 0;

    for(int i = 0 ; i < maxReadsPerFile; i++){ // reading the references from the trace and writting the to shared memory

      char ref[9];
      char action;


      if(getline(&line, &len, gen_fp) == -1) {//reads the line
        fileFinished = 1;
        break;
      }

      strtok(line," ");
      strcpy(ref , line);
      line = strtok(NULL," ");
      action = line[0];
      ref[9] = 0;


      strcpy((sharedMem->dataArray[i]).ref , ref);//copies the reference
      (sharedMem->dataArray[i]).action = action;

      if (definedMaxNumR == 1){//checks for maximum reference reads
        numOfReads++;
        if (numOfReads >= maxNumberOfReads){
          break;
        }
      }
    }

    if(fileFinished == 1){//if the file has no more data signifies that the data we are about to send are the last
      sharedMem->lastData = true;
    }
    else if (definedMaxNumR == 1){ // if we have reached the reference read limit , we signify that the data we are about to send are the last
      if(numOfReads >= maxNumberOfReads){
        sharedMem->lastData = true;
      }
    }

    if (disconnectData(sharedMem) != 0){//disconnects shared memory
      exit(1);
    }

    if(sem_up(sem_id , 0) < 0){ //brings memory semaphore up
      exit(1);
    }

    if(sem_up(sem_id , 3) < 0){ //brigns MM sepaphore up
      exit(1);
    }

  }
  fclose(gen_fp);
} 
