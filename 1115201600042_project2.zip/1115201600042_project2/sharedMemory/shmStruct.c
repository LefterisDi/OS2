#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "shmStruct.h"
#include "shmCtrl.h"

Data* connectData(key_t dataKey , key_t refArrayKey , int who){
    
    int shmid;
    Data* dataSharedMem;

    int refid;

    if ((shmid = shmget(dataKey , 0 , 0)) < 0) {
     perror("shmget!\n");
     return(0);
    }


   if((dataSharedMem = (Data*)shmat(shmid , 0 , 0)) < 0){
      perror("shmat error!");
      return(0);
   }


    if ((refid = shmget(refArrayKey, 0 , 0)) < 0) {
        perror("shmget!\n");
        return(0);
    }

    if((dataSharedMem->dataArray = (Ref*)shmat(refid , 0 , 0)) < 0){
        perror("shmat error!");
        return(0);
    }


    return dataSharedMem;
    
}

int disconnectData(Data* sharedMem){
    if(shmdt(sharedMem->dataArray) < 0){
        perror("shmdt error!");
        return(1);
    }
    if(shmdt(sharedMem) < 0){
        perror("shmdt error!");
        return(1);
    }

    return 0;
}

void clearBuffer(Data* sharedMem , int capacity){
    
    for(int i = 0; i < capacity ; i++){
        Ref *reference = &sharedMem->dataArray[i];
        for(int j = 0 ; j < 8 ; j++){
            reference->ref[j] = 0;
        }
        reference->ref[9] = 0;
        reference->action = 0;
    }
    
}

Data* createData(key_t dataKey , key_t refArrayKey , int capacity){

    int shmid;
    Data* sharedMem;

    int refArrayID;
    Ref* refArSharedMem;


    if ((shmid = shmget(dataKey, sizeof(Data) , IPC_CREAT | 0666)) < 0) {
        perror("shmget!\n");
        return NULL;
    }

   if((sharedMem = (Data*)shmat(shmid , 0 , 0)) < 0){
        perror("shmat error!");
        return NULL;
   }


    if ((refArrayID = shmget(refArrayKey , capacity * sizeof(Ref), IPC_CREAT | 0666)) < 0) {
        perror("shmget!\n");
        return(NULL);
    }

    if((refArSharedMem = shmat(refArrayID , 0 , 0)) < 0){
        perror("shmat error!");
        return(NULL);
    }


    sharedMem->dataArray = refArSharedMem;

    sharedMem->lastData = false;

    clearBuffer(sharedMem , capacity);

    return sharedMem;
}


int deleteData(key_t dataKey , key_t refArrayKey){
    
    int refid;
    int dataid;

    if ((refid = shmget(refArrayKey, 0 , 0)) < 0) {
        perror("shmget!\n");
        return(-1);
    }

    if ((dataid = shmget(dataKey, 0 , 0)) < 0) {
        perror("shmget!\n");
        return(-1);
    }

    if(shm_delete(refid) < 0){
        perror("shared memory delete error!");
        exit(-1);
    }

    if(shm_delete(dataid) < 0){
        perror("shared memory delete error!");
        exit(-1);
    }

}