#ifndef __SHM_STRUCT_H__
#define __SHM_STRUCT_H__

#include <stdbool.h>
#include <sys/types.h>

typedef struct Ref{
    char ref[9];
    char action;
}Ref;

typedef struct Data{
    bool lastData;
    Ref* dataArray;
}Data;

Data* createData(key_t , key_t , int);
Data* connectData(key_t , key_t , int);
int deleteData(key_t, key_t);
void clearBuffer(Data* , int);
int disconnectData(Data*);

#endif
