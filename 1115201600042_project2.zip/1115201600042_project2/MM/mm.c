#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <math.h>

#include "../sharedMemory/shmStruct.h"
#include "../sharedMemory/shmCtrl.h"
#include "../semaphores/semCtrl.h"
#include "../list/list.h"
#include "./mm.h"

void FWF(char** , int , ListNode** , int);

int main(int argc , char* argv[]){

    int maxPageFaults;
    int numberOfCells;
    int maxReadsPerFile;
    int maxNumberOfReads = 1;  
    int numOfBuckets;

    int remainingFramesPM1;
    int remainingFramesPM2;

    int maxFramesPM1;
    int maxFramesPM2;

    int modRefsWtoDiskPM1 = 0;
    int modRefsWtoDiskPM2 = 0;

    int readsOnDiskPM1 = 0;
    int readsOnDiskPM2 = 0;
    
    int writesOnDiskPM1 = 0;
    int writesOnDiskPM2 = 0;

    int pageFaultsPM1 = 0;
    int pageFaultsPM2 = 0;

    int refsCamePM1 = 0;
    int refsCamePM2 = 0;

    int numOfFramesTakenPM1 = 0;
    int numOfFramesTakenPM2 = 0;    

    ListNode** dataArray;

    ListNode* modifArrayPM1 = NULL;
    ListNode* modifArrayPM2 = NULL;

    key_t shm;
    key_t array;
    int shm_id;
    Data* sharedMem;

    key_t sem;
    int sem_id;
        
        
    while(--argc > 0){
    
    if (strcmp(*argv , "-K") == 0){
      argv++;
      argc--;
      maxPageFaults = atoi(*argv);
    }

    if (strcmp(*argv , "-Q") == 0){
      argv++;
      argc--;
      maxReadsPerFile = atoi(*argv);
    }

    if (strcmp(*argv , "-C") == 0){
      argv++;
      argc--;
      numberOfCells = atoi(*argv);
      numOfBuckets = numberOfCells;
      maxFramesPM1 = (int)ceil(numberOfCells / 2.0);
      maxFramesPM2 = (int)(numberOfCells / 2.0);
      remainingFramesPM1 = maxFramesPM1;
      remainingFramesPM2 = maxFramesPM2;
    }

     if (strcmp(*argv , "-M") == 0){
      argv++;
      argc--;
      maxNumberOfReads = atoi(*argv);
    }

    if (argc > 0){
      argv++;
    }
  }
  

  dataArray = malloc(numOfBuckets*sizeof(ListNode*)); // allocates the hash table
  

  for (int i = 0 ; i < numOfBuckets ; i++){//initializes the hash table "buckets" to NULL
    dataArray[i] = NULL;
  }

  shm = get_shmemkey("./shmem.key");
  array = get_shmemkey("./shmemArray.key");

  sem = get_semkey("./sem.key");
  sem_id = semget(sem , 0 , 0);

  int pageFaultsForCrlPM1 = 0;
  int pageFaultsForCrlPM2 = 0;  
  int lastRef1 = 0;
  int lastRef2 = 0;
  int typeOfPm = 1;
  char** frameRefsPM1 = malloc(maxFramesPM1 * sizeof(char*));//makes an array to keep the references that are on the first half of the page table(from PM1)
  for (int i = 0 ; i < maxFramesPM1 ; i++){
    frameRefsPM1[i] = malloc(6*sizeof(char));
  }
  char** frameRefsPM2 = malloc(maxFramesPM2 * sizeof(char*));//makes an array to keep the references that are on the second half of the page table(from PM2)
  for (int i = 0 ; i < maxFramesPM2 ; i++){
    frameRefsPM2[i] = malloc(6*sizeof(char));
  }

  clearArray(&frameRefsPM1 , maxFramesPM1);//initializes these arrays
  clearArray(&frameRefsPM2 , maxFramesPM2);


  while (!(lastRef1 == 1 && lastRef2 == 1)){

  
    if(sem_up(sem_id , typeOfPm) < 0){ //brings up the semaphore of either PM1 or PM2
      exit(1);
    }
    
    if(sem_down(sem_id , 3) < 0){ //brings down its own semaphore
      exit(1);
    }


    if(sem_down(sem_id , 0) < 0){ //brings down the memory semaphore
      exit(1);
    }


    sharedMem = connectData(shm , array , 3);//connects the memory



    for(int i = 0 ; i < maxReadsPerFile ; i++){

      
      int index = -1;
      char hexPageNum[6];
      HashData* data;
      int isIn = 0;

      if (sharedMem->dataArray[i].ref[0] == 0){ // if there are no more references in the shared memory stop reading
        break;
      }

      if (sharedMem->dataArray[i].action == 'W'){//checks whether we want to read or write to the Disk
        switch(typeOfPm){
          case 1:
            writesOnDiskPM1++;
            break;
          
          case 2:
            writesOnDiskPM2++;
            break;
        }
      }
      else if (sharedMem->dataArray[i].action == 'R'){
        switch(typeOfPm){
          case 1:
            readsOnDiskPM1++;
            break;
          
          case 2:
            readsOnDiskPM2++;
            break;
        }
      }

      index = HashFunction(sharedMem->dataArray[i].ref , numOfBuckets);//gets the index of a bucket for the hash table

      if (index == -1){
        perror("Hash function faillure");
        exit(1);
      }

      for (int j = 0; j < 5; j++){//copies the reference to a variable
        hexPageNum[j] = sharedMem->dataArray[i].ref[j];
      }
      hexPageNum[5] = 0;

      if(search_in_list(hexPageNum , dataArray[index]) == 0){//checks if the reference is already inside the table
        isIn = 1;
      }
      else {
        isIn = 0;
        switch(typeOfPm){//counting page faults
          case 1:
            pageFaultsPM1++;
            pageFaultsForCrlPM1++;
            break;
          
          case 2:
            pageFaultsPM2++;
            pageFaultsForCrlPM2++;
            break;
        }
      }

      if (isIn == 0){

        switch(typeOfPm){//checks whether FWF condition are met or , when k > c/2 , if the page table is full
          case 1:
            if (pageFaultsForCrlPM1 == maxPageFaults + 1){//if page fault > k
              pageFaultsForCrlPM1 = 0;
              remainingFramesPM1 = maxFramesPM1;
              while(delete_from_begin(&modifArrayPM1) == 0){
                modRefsWtoDiskPM1++;
              }
              FWF(frameRefsPM1,maxFramesPM1,dataArray,numOfBuckets);
            }
            else if(remainingFramesPM1 == 0){//if PT is full
              pageFaultsForCrlPM1 = 0;
              remainingFramesPM1 = maxFramesPM1;
              while(delete_from_begin(&modifArrayPM1) == 0){
                modRefsWtoDiskPM1++;
              }
              FWF(frameRefsPM1,maxFramesPM1,dataArray,numOfBuckets);  
            }
            break;

          case 2:
            if (pageFaultsForCrlPM2 == maxPageFaults + 1){
              pageFaultsForCrlPM2 = 0;
              remainingFramesPM2 = maxFramesPM2;
              while(delete_from_begin(&modifArrayPM2) == 0){
                modRefsWtoDiskPM2++;
              }
              FWF(frameRefsPM2,maxFramesPM2,dataArray,numOfBuckets);
            }
            else if(remainingFramesPM2 == 0){
              pageFaultsForCrlPM2 = 0;
              remainingFramesPM2 = maxFramesPM2;
              while(delete_from_begin(&modifArrayPM2) == 0){
                modRefsWtoDiskPM2++;
              }
              FWF(frameRefsPM2,maxFramesPM2,dataArray,numOfBuckets);  
            }
            break;
        }       
            
        int frameIndex;

        if (typeOfPm == 1){// copies the reference to the page table . The "where" depends on which proccess gave this reference.
          frameIndex = maxFramesPM1 - remainingFramesPM1;
          remainingFramesPM1--;
          strncpy(frameRefsPM1[frameIndex] , hexPageNum , 6);
        }
        else if (typeOfPm == 2){
          frameIndex = maxFramesPM2 - remainingFramesPM2;
          remainingFramesPM2--;
          strncpy(frameRefsPM2[frameIndex] , hexPageNum , 6);
        }

        switch(typeOfPm){//lastly inserts the data created to the hash table
          case 1:
            data = CreateHashData(hexPageNum , frameIndex);        
            break;
          case 2:
            data = CreateHashData(hexPageNum , frameIndex + maxFramesPM1);
        }
        
        insert_at_begin(*data , &dataArray[index]);

        switch(typeOfPm){
          case 1:
            numOfFramesTakenPM1++;
            break;
          case 2:
            numOfFramesTakenPM2++;
            break;
        }

      }
      else{
        if (sharedMem->dataArray[i].action == 'W'){//"saves" the pages that , if removed from the PT need to be saved to the disk 
          HashData* tempData;
          tempData = CreateHashData(hexPageNum , -1);
          switch(typeOfPm){
            case 1:
              insert_at_begin(*tempData , &modifArrayPM1);              
              break;
            case 2:
              insert_at_begin(*tempData , &modifArrayPM2);              
              break;
          }      
        }
      }

      switch(typeOfPm){
        case 1:
          refsCamePM1++;
          break;
        case 2:
          refsCamePM2++;
          break;
      }

    }

    clearBuffer(sharedMem , maxReadsPerFile);//clears the shared memory from all references

    if (sharedMem->lastData == 1 && typeOfPm == 1){//if lastData == 1 for both proccesses then we should "end" the simulation
      lastRef1 = 1;
    }
    else if (sharedMem->lastData == 1 && typeOfPm == 2) {
      lastRef2 = 1;
    }

    if (disconnectData(sharedMem) != 0){//detaches MM from shared memory
      exit(1);
    }

    if(sem_up(sem_id , 0) < 0){ //brings the shared memory semaphore up
      exit(1);
    }


    switch(typeOfPm){//switches to PM2 from PM1 or from PM1 to PM2.
      case 1:
        typeOfPm = 2;
        break;
      
      case 2:
        typeOfPm = 1;
        break;
    }
  }

  int finalFramesHeldPM1 = 0;
  int finalFramesHeldPM2 = 0;

  for (int i = 0 ; i < maxFramesPM1 ; i++){
    if(frameRefsPM1[i][0] != 0){
      finalFramesHeldPM1++;
    }
  }

  for (int i = 0 ; i < maxFramesPM2 ; i++){
    if(frameRefsPM2[i][0] != 0){
      finalFramesHeldPM2++;
    }
  }

  printf("\nTotal references came : %d \n-> %d from PM1 \n-> %d from PM2\n\n" , refsCamePM1 + refsCamePM2 , refsCamePM1 , refsCamePM2);
  printf("Total number of Frames taken : %d \n-> %d from PM1 \n-> %d from PM2\n\n" , numOfFramesTakenPM1 + numOfFramesTakenPM2 , numOfFramesTakenPM1 , numOfFramesTakenPM2);
  printf("Total reads from disk : %d \n-> %d from PM1 \n-> %d from PM2\n\n",readsOnDiskPM1 + readsOnDiskPM2 , readsOnDiskPM1 , readsOnDiskPM2);
  printf("Total writes to disk : %d \n-> %d from PM1 \n-> %d from PM2\n\n",writesOnDiskPM1 + writesOnDiskPM2 , writesOnDiskPM1 , writesOnDiskPM2);
  printf("Total page faults : %d \n-> %d from PM1 \n-> %d from PM2\n\n",pageFaultsPM1 + pageFaultsPM2 , pageFaultsPM1 , pageFaultsPM2);
  printf("Modified references saved to disk(because of eviction) : %d \n-> %d from PM1 \n-> %d from PM2\n\n" , modRefsWtoDiskPM1 + modRefsWtoDiskPM2 , modRefsWtoDiskPM1 , modRefsWtoDiskPM2);
  printf("Number of last frames held in the page table before the simulation ended : %d \n-> %d from PM1 \n-> %d from PM2\n\n" , finalFramesHeldPM1 + finalFramesHeldPM2 , finalFramesHeldPM1 , finalFramesHeldPM2);


  //Frees everything ... FOR FREEDOOOOO... *GOUH* , sorry about that ... 

 

  for (int i = 0 ; i < maxFramesPM1 ; i++){
    free(frameRefsPM1[i]);
  }
  free(frameRefsPM1);
  
  for (int i = 0 ; i < maxFramesPM2 ; i++){
    free(frameRefsPM2[i]);
  }
  free(frameRefsPM2);

  for (int i = 0 ; i < numOfBuckets ; i++){
    while(delete_from_begin(&dataArray[i]) == 0);
  }
  free(dataArray);

  while(delete_from_begin(&modifArrayPM1) == 0);
  free(modifArrayPM1);

  while(delete_from_begin(&modifArrayPM2) == 0);
  free(modifArrayPM2);
} 


int HashFunction(char* elemIndex , int buckets){//calculates and produces in index for the reference to the hash table

  int sum = 0;
  for (int i = 0 ; i < 5 ; i++){
    sum += elemIndex[i];
  }

  return sum % buckets;
} 


HashData* CreateHashData(char* pageN , int frameIndex){//creates hash table data
  
  HashData* data;
  int numOfBits = 0;
  char* heheboi;
  
  data = malloc(sizeof(HashData));
  for (int i = 0 ; i < 5 ; i++){
    data->pageNum[i] = pageN[i];
  }
  data->pageNum[5] = 0;

  data->frameNum = frameIndex;

  return data;
}

void clearArray(char*** array, int capacity){//fills a 2D array with NULL
  for (int i = 0; i < capacity ; i++){
    for(int j = 0 ; j < 6 ; j++){
      (*array)[i][j] = 0;
    }
  }
}

void FWF(char** array , int maxFrames , ListNode** dataArray , int numOfBuckets){//goes through the given page table and deletes the references from the hash table
//also cleares the PT

  int index;

  for (int i = 0 ; i < maxFrames ; i++){
    if (array[i][0] == 0){
      break;
    }
    index = HashFunction( array[i] , numOfBuckets);
    delete_from_list(&dataArray[index] , array[i]);
    for (int j = 0 ; j < 6 ; j++){
      array[i][j] = 0;
    }
  }

}