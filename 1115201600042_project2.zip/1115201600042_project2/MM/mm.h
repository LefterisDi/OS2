#ifndef __MM_H__
#define __MM_H__

typedef struct HashData{
    char pageNum[6];
    int frameNum;
}HashData;


int HashFunction(char* , int);
HashData* CreateHashData(char* , int);
void clearArray(char*** , int);
#endif