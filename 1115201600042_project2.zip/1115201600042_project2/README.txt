***************************************************************************************************
->GENERAL:

    HOW ARE REFERENCES PROCCESSED :
    
    References given to the program from the files are proccessed in the following way:
    
    1) The last 3 digits of the references are cut because they are offset .(since the pages are
    4096 bytes = 2^12 bytes . Every hexadecimal digits is equal to 4 bytes.)
    
    2) The rest is considered as the page number . (The page number is not converted to binary
    by the simulation and is stored as is , since this doesn't affect the functionality of the 
    simulation)
    
    3) The frame number is stored as an integer showing the frame the page is stored.

    HOW TO COMPILE & RUN :
    
    Use "make" to compile and "make clean" to clear everything produced
    by the simulation program.

    Run the program like so:
    e.x.
    ./sim -K 1 -Q 2 -C 10 -M 10

    K -> Maximum accepted page faults until the page table is cleared using FWF.

    Q -> Signifies how many references will be read per file every time a file gives
    references to MM.

    C -> Total number of frames.

    (Optional) M -> Maximum number of references to be read from each file.

    ***IF A K IS GIVEN SO THAT K > C/2 THEN FWF IS USED WHEN THE PT IS FULL AND NOT WHEN
    THE NUMBER OF PAGE FAULTS BECOMES GREATER THAN K !!!

***************************************************************************************************

->SHARING DATA BETWEEN PROCCESSES :
    In order for the proccesses to share data , i used shared memory . Specifically a struct is
    used with enough memory to hold Q references . So the references are given to MM in groups and
    NOT singularly .
    
***************************************************************************************************

->SEMAPHORES :
    4 semaphores were used . 3 of the semaphores were used as ON/OFF switches for the proccesses
    PM1,PM2,MM in order to control which proccess was ready to continue its assigned job.
    The last semaphore was used for the shared memory segment , so that 2 proccesses can't use it
    at the same time.
    
***************************************************************************************************

->HASHED PAGE TABLE:
    Only one hash table is used for both proccess since we use the hash table to quickly find
    references and where they are stored in the page table. The page table instead of being 
    simulated by one array , it is broken in two , strictly because of clarity.These two
    arrays are NOT treated as separate page tables.
    
***************************************************************************************************

->RESULTS :

    K = 10 , Q = 5 , C = 200 :
    
    M = MAX(time : real 0m10.248s)
    
    Total references came : 2000000 
    -> 1000000 from PM1 
    -> 1000000 from PM2

    Total number of Frames taken : 218838 
    -> 6555 from PM1 
    -> 212283 from PM2

    Total reads from disk : 1770397 
    -> 877581 from PM1 
    -> 892816 from PM2

    Total writes to disk : 229603 
    -> 122419 from PM1 
    -> 107184 from PM2

    Total page faults : 218838 
    -> 6555 from PM1 
    -> 212283 from PM2

    Modified references saved to disk(because of eviction) : 200958 
    -> 117143 from PM1 
    -> 83815 from PM2
    
    Number of last frames held in the page table before the simulation ended : 17 
    -> 11 from PM1 
    -> 6 from PM2


 ################################################################################
     
    K = 20 , Q = 5 , C = 200 :
    
    M = MAX(time : real 0m9.877s)
    
    Total references came : 2000000 
    -> 1000000 from PM1 
    -> 1000000 from PM2

    Total number of Frames taken : 153567 
    -> 4399 from PM1 
    -> 149168 from PM2

    Total reads from disk : 1770397 
    -> 877581 from PM1 
    -> 892816 from PM2

    Total writes to disk : 229603 
    -> 122419 from PM1 
    -> 107184 from PM2

    Modified references saved to disk(because of eviction) : 209626 
    -> 117374 from PM1 
    -> 92252 from PM2

    Number of last frames held in the page table before the simulation ended : 17 
    -> 11 from PM1 
    -> 6 from PM2

    
################################################################################
     
    K = 50 , Q = 5 , C = 200 :
    
    M = MAX(time : real 0m9.780s)

    Total references came : 2000000 
    -> 1000000 from PM1 
    -> 1000000 from PM2

    Total number of Frames taken : 101176 
    -> 2121 from PM1 
    -> 99055 from PM2

    Total reads from disk : 1770397 
    -> 877581 from PM1 
    -> 892816 from PM2

    Total writes to disk : 229603 
    -> 122419 from PM1 
    -> 107184 from PM2

    Total page faults : 101176 
    -> 2121 from PM1 
    -> 99055 from PM2

    Modified references saved to disk(because of eviction) : 188097 
    -> 90492 from PM1 
    -> 97605 from PM2

    Number of last frames held in the page table before the simulation ended : 45 
    -> 31 from PM1 
    -> 14 from PM2

    
################################################################################
     
    K = 80 , Q = 5 , C = 200 :
    
    M = MAX(time : real 0m10.033s)
    
    
    Total references came : 2000000 
    -> 1000000 from PM1 
    -> 1000000 from PM2

    Total number of Frames taken : 78329 
    -> 1617 from PM1 
    -> 76712 from PM2

    Total reads from disk : 1770397 
    -> 877581 from PM1 
    -> 892816 from PM2

    Total writes to disk : 229603 
    -> 122419 from PM1 
    -> 107184 from PM2

    Total page faults : 78329 
    -> 1617 from PM1 
    -> 76712 from PM2

   Modified references saved to disk(because of eviction) : 132032 
    -> 32405 from PM1 
    -> 99627 from PM2

    Number of last frames held in the page table before the simulation ended : 85 
    -> 79 from PM1 
    -> 6 from PM2


 ################################################################################  
 
    K = 90 , Q = 5 , C = 200 :
    
    M = MAX(time : real 0m10.026s)
    
    Total references came : 2000000 
    -> 1000000 from PM1 
    -> 1000000 from PM2

    Total number of Frames taken : 72868 
    -> 1449 from PM1 
    -> 71419 from PM2

    Total reads from disk : 1770397 
    -> 877581 from PM1 
    -> 892816 from PM2

    Total writes to disk : 229603 
    -> 122419 from PM1 
    -> 107184 from PM2

    Total page faults : 72868 
    -> 1449 from PM1 
    -> 71419 from PM2

   Modified references saved to disk(because of eviction) : 132366 
    -> 32323 from PM1 
    -> 100043 from PM2

    Number of last frames held in the page table before the simulation ended : 161 
    -> 85 from PM1 
    -> 76 from PM2


 ################################################################################  
    
    K = 100 , Q = 5 , C = 200 :
 
    M = Max(time : real 0m10.107s)
    
    Total references came : 2000000 
    -> 1000000 from PM1 
    -> 1000000 from PM2

    Total number of Frames taken : 70316 
    -> 1390 from PM1 
    -> 68926 from PM2

    Total reads from disk : 1770397 
    -> 877581 from PM1 
    -> 892816 from PM2

    Total writes to disk : 229603 
    -> 122419 from PM1 
    -> 107184 from PM2

    Total page faults : 70316 
    -> 1390 from PM1 
    -> 68926 from PM2

   Modified references saved to disk(because of eviction) : 132664 
    -> 32231 from PM1 
    -> 100433 from PM2

    Number of last frames held in the page table before the simulation ended : 116 
    -> 90 from PM1 
    -> 26 from PM2


 ################################################################################ 
 
    K = 200 , Q = 5 , C = 200
 
    M = MAX(time : real 0m9.744s)
 
    Total references came : 2000000 
    -> 1000000 from PM1 
    -> 1000000 from PM2

    Total number of Frames taken : 70316 
    -> 1390 from PM1 
    -> 68926 from PM2

    Total reads from disk : 1770397 
    -> 877581 from PM1 
    -> 892816 from PM2

    Total writes to disk : 229603 
    -> 122419 from PM1 
    -> 107184 from PM2

    Modified references saved to disk(because of eviction) : 132664 
    -> 32231 from PM1 
    -> 100433 from PM2

    Number of last frames held in the page table before the simulation ended : 116 
    -> 90 from PM1 
    -> 26 from PM2

    
    
 ################################################################################ 
    
    K = 90 , Q = 5000 , C = 200 :
    
    M = MAX(time : real 0m10.026s)
    
    Total references came : 2000000 
    -> 1000000 from PM1 
    -> 1000000 from PM2

    Total number of Frames taken : 72868 
    -> 1449 from PM1 
    -> 71419 from PM2

    Total reads from disk : 1770397 
    -> 877581 from PM1 
    -> 892816 from PM2

    Total writes to disk : 229603 
    -> 122419 from PM1 
    -> 107184 from PM2

    Total page faults : 72868 
    -> 1449 from PM1 
    -> 71419 from PM2

    Modified references saved to disk(because of eviction) : 132363 
    -> 32323 from PM1 
    -> 100040 from PM2

    Number of last frames held in the page table before the simulation ended : 161 
    -> 85 from PM1 
    -> 76 from PM2


    WE NOTICE THAT INCREASING Q DOES MAKE A SIGNIFICANT DIFFERENCE ON OUR DATA , BUT
    IT MAKES THE SIMULATION A LOT FASTER.HOWEVER IF WE INCREASE THE FRAMES , AS WELL AS K :
    
    K = 9000 , Q = 5000 , C = 20000
 
    M = MAX(time : real 0m1.183s)
    
    
   Total references came : 2000000 
    -> 1000000 from PM1 
    -> 1000000 from PM2

    Total number of Frames taken : 3157 
    -> 316 from PM1 
    -> 2841 from PM2

    Total reads from disk : 1770397 
    -> 877581 from PM1 
    -> 892816 from PM2

    Total writes to disk : 229603 
    -> 122419 from PM1 
    -> 107184 from PM2

    Modified references saved to disk(because of eviction) : 0 
    -> 0 from PM1 
    -> 0 from PM2

    Number of last frames held in the page table before the simulation ended : 3157 
    -> 316 from PM1 
    -> 2841 from PM2

    
    THE PAGE FAULTS BECOME WAY LESS THAN THE PREVIOUS EXAMPLES.(MORE THAN 20 TIMES LESS)
    ALSO NO MODIFIED PAGES WERE EVICTED .
    
    
